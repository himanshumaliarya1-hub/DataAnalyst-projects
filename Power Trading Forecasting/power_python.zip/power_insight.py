# -*- coding: utf-8 -*-
"""
Created on Sun May  3 12:16:25 2026

@author: Himanshu
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# ==========================================
# 1. SETUP & LOAD DATA
# ==========================================
print("Loading data and setting up...")
df = pd.read_csv(r"C:\Users\Himanshu\Downloads\IEX_Weather_final.csv")

# Clean headers just in case
df.columns = df.columns.str.strip().str.replace(' ', '_').str.replace('/', '_').str.replace('*', '')

numeric_cols = df.select_dtypes(include=[np.number]).columns
target_col = 'MCP_Rs_MWh' # Set your target for the Bivariate Scatter Plot

# Create a temporary folder to hold the images before they go into Excel
img_folder = 'Temp_Excel_Images'
if not os.path.exists(img_folder):
    os.makedirs(img_folder)

# ==========================================
# 2. CREATE EXCEL WORKBOOK
# ==========================================
output_file = 'Power_Trading_Master_EDA.xlsx'
writer = pd.ExcelWriter(output_file, engine='xlsxwriter')

# --- NEW LINE: Dump all the raw rows into the first tab ---
print("Writing raw data to the first sheet...")
df.to_excel(writer, sheet_name='Raw Data', index=False)



workbook = writer.book
worksheet = workbook.add_worksheet('Business Insights')

# --- NEW LINE: Dump all the raw rows into the first tab ---
print("Writing raw data to the first sheet...")
df.to_excel(writer, sheet_name='Raw Data', index=False)

# Excel Formatting Styles
wrap_format = workbook.add_format({'text_wrap': True, 'valign': 'top', 'border': 1})
header_format = workbook.add_format({'bold': True, 'bg_color': '#D9E1F2', 'border': 1, 'align': 'center'})

# Set Column Widths (Wide enough for images and text)
worksheet.set_column('A:A', 25) # Column Name
worksheet.set_column('B:D', 30, wrap_format) # Stats columns
worksheet.set_column('E:G', 40) # Image columns (Histogram, Boxplot, Scatter)

# Write Headers
headers = [
    'Column Name', '1st Moment (Mean/Median/Mode)', '2nd Moment (Var/Std/Range)', 
    '3rd Moment (Skewness)', 'Histogram (Distribution)', 'Boxplot (Outliers)', f'Bivariate vs {target_col}'
]
for col_num, header_text in enumerate(headers):
    worksheet.write(0, col_num, header_text, header_format)

# ==========================================
# 3. PROCESS EVERY COLUMN
# ==========================================
print("Calculating stats, generating plots, and building Excel file. Please wait...")

row_num = 1 # Start writing data on row 2 (index 1 in Python)

for col in numeric_cols:
    # Set the row height tall enough to fit the images (approx 150 pixels)
    worksheet.set_row(row_num, 150)
    
    # --- 1. CALCULATE STATS ---
    mean_val = df[col].mean()
    median_val = df[col].median()
    mode_series = df[col].mode()
    mode_val = mode_series[0] if not mode_series.empty else np.nan
    var_val = df[col].var()
    std_val = df[col].std()
    range_val = df[col].max() - df[col].min()
    skew_val = df[col].skew()

    first_moment = f"Mean: {mean_val:.4f}\nMedian: {median_val:.4f}\nMode: {mode_val:.4f}"
    second_moment = f"Variance: {var_val:.4f}\nStdev: {std_val:.4f}\nRange: {range_val:.4f}"
    third_moment = f"Skewness: {skew_val:.4f}"
    
    # Write text to Excel
    worksheet.write(row_num, 0, col, wrap_format)
    worksheet.write(row_num, 1, first_moment, wrap_format)
    worksheet.write(row_num, 2, second_moment, wrap_format)
    worksheet.write(row_num, 3, third_moment, wrap_format)
    
    # --- 2. GENERATE AND SAVE PLOTS (Small size for Excel) ---
    safe_col = str(col).replace('/', '_').replace('*', '').replace('\\', '_')
    
    # Histogram
    fig_hist, ax_hist = plt.subplots(figsize=(4, 2.5)) # Small size
    sns.histplot(df[col], kde=True, color='skyblue', ax=ax_hist)
    ax_hist.set_title('Histogram', fontsize=10)
    plt.tight_layout()
    hist_path = f"{img_folder}/hist_{safe_col}.png"
    plt.savefig(hist_path, dpi=100)
    plt.close(fig_hist)
    
    # Boxplot
    fig_box, ax_box = plt.subplots(figsize=(4, 2.5))
    sns.boxplot(x=df[col], color='lightgreen', ax=ax_box)
    ax_box.set_title('Boxplot', fontsize=10)
    plt.tight_layout()
    box_path = f"{img_folder}/box_{safe_col}.png"
    plt.savefig(box_path, dpi=100)
    plt.close(fig_box)
    
    # Scatter Plot (Bivariate)
    scatter_path = ""
    if col != target_col and target_col in df.columns:
        fig_scat, ax_scat = plt.subplots(figsize=(4, 2.5))
        sns.scatterplot(x=df[col], y=df[target_col], alpha=0.5, color='teal', ax=ax_scat)
        ax_scat.set_title(f'Scatter vs {target_col}', fontsize=10)
        plt.tight_layout()
        scatter_path = f"{img_folder}/scat_{safe_col}.png"
        plt.savefig(scatter_path, dpi=100)
        plt.close(fig_scat)

    # --- 3. INSERT IMAGES INTO EXCEL ---
    # We use {'x_scale': 0.8, 'y_scale': 0.8} to shrink the image slightly so it fits perfectly in the cell
    worksheet.insert_image(row_num, 4, hist_path, {'x_scale': 0.8, 'y_scale': 0.8, 'positioning': 1})
    worksheet.insert_image(row_num, 5, box_path, {'x_scale': 0.8, 'y_scale': 0.8, 'positioning': 1})
    
    if scatter_path:
        worksheet.insert_image(row_num, 6, scatter_path, {'x_scale': 0.8, 'y_scale': 0.8, 'positioning': 1})

    row_num += 1

# Save and close the Excel file
writer.close()

print(f"\n✅ MASTER EXCEL FILE CREATED: {output_file}")
print("You can now open this file in Excel to see your data and images side-by-side!")