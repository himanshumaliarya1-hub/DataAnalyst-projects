# -*- coding: utf-8 -*-
"""
Created on Fri May  1 18:54:48 2026

@author: Himanshu
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os 

# ==========================================
# 1. DATA LOADING
# ==========================================
# Replace with the path to your file once you have it
file_path = r'D:\numpy\power trading analysis\Dataset\New folder\IEX_Weather_final.csv'

# Load the data (equivalent to LOAD DATA LOCAL INFILE)
df = pd.read_csv(file_path)

print("--- Data Successfully Loaded ---")
(df.head(10))

# ==========================================
# 2. TOTAL RECORDS & BASIC COUNTS
# ==========================================
print("\n--- Basic Counts ---")
print(f"Total Records (Rows): {len(df)}")
print(f"Total Columns: {len(df.columns)}")

print(f"Distinct Dates: {df['Date'].nunique()}")
print(f"Start Date: {df['Date'].min()}")
print(f"End Date: {df['Date'].max()}")
print(f"Distinct Hours: {df['Hour'].nunique()}")
print(f"Distinct Time Blocks: {df['Time Block'].nunique()}")

# ==========================================
# 3. MISSING VALUES & DUPLICATES
# ==========================================
print("\n--- Duplicate Rows ---")
# Check for duplicates based on Date and Hour
duplicates = df[df.duplicated(subset=['Date', 'Hour'], keep=False)]
print(f"Total Duplicate records based on Date & Hour: {len(duplicates)}")

columns_to_check = df.columns.difference(['Date', 'Hour', 'Time_Block'])

# Find duplicates using that list
duplicates1 = df[df.duplicated(subset=columns_to_check, keep=False)]
# find all duplicates in every column

print(f"Found {len(duplicates1)} duplicate rows.")

# Fixed Code
duplicates1 = df[df.duplicated(subset=[
    'Purchase Bid (MW)', 'Sell Bid (MW)', 'MCV (MW)', 'Final Scheduled Volume (MW)', 
    'MCP (Rs/MWh) *', 'time', 'Mundra_temperature_2m (°C)', 'Mundra_relative_humidity_2m (%)', 
    'Mundra_cloud_cover (%)', 'Mundra_wind_speed_10m (km/h)', 'Mundra_shortwave_radiation (W/m²)', 
    'RamaGundem_temperature_2m (°C)', 'RamaGundem_relative_humidity_2m (%)', 'RamaGundem_cloud_cover (%)', 
    'RamaGundem_wind_speed_10m (km/h)', 'RamaGundem_shortwave_radiation (W/m²)', 'Vindhyachal_temperature_2m (°C)', 
    'Vindhyachal_relative_humidity_2m (%)', 'Vindhyachal_cloud_cover (%)', 'Vindhyachal_wind_speed_10m (km/h)', 
    'Vindhyachal_shortwave_radiation (W/m²)', 'Bhadla_temperature_2m (°C)', 'Bhadla_relative_humidity_2m (%)', 
    'Bhadla_cloud_cover (%)', 'Bhadla_wind_speed_10m (km/h)', 'Bhadla_shortwave_radiation (W/m²)', 
    'Akaltara_temperature_2m (°C)', 'Akaltara_relative_humidity_2m (%)', 'Akaltara_cloud_cover (%)', 
    'Akaltara_wind_speed_10m (km/h)', 'Akaltara_shortwave_radiation (W/m²)', 'Khavda_temperature_2m (°C)', 
    'Khavda_relative_humidity_2m (%)', 'Khavda_cloud_cover (%)', 'Khavda_wind_speed_10m (km/h)', 
    'Khavda_shortwave_radiation (W/m²)', 'Muppandal_temperature_2m (°C)', 'Muppandal_relative_humidity_2m (%)', 
    'Muppandal_cloud_cover (%)', 'Muppandal_wind_speed_10m (km/h)', 'Muppandal_shortwave_radiation (W/m²)', 
    'Srisailam_temperature_2m (°C)', 'Srisailam_relative_humidity_2m (%)', 'Srisailam_cloud_cover (%)', 
    'Srisailam_wind_speed_10m (km/h)', 'Srisailam_shortwave_radiation (W/m²)', 'Tehri_temperature_2m (°C)', 
    'Tehri_relative_humidity_2m (%)', 'Tehri_cloud_cover (%)', 'Tehri_wind_speed_10m (km/h)', 
    'Tehri_shortwave_radiation (W/m²)', 'Blr_temperature_2m (°C)', 'Blr_relative_humidity_2m (%)', 
    'Blr_cloud_cover (%)', 'Blr_wind_speed_10m (km/h)', 'Blr_shortwave_radiation (W/m²)', 
    'Chn_temperature_2m (°C)', 'Chn_relative_humidity_2m (%)', 'Chn_cloud_cover (%)', 
    'Chn_wind_speed_10m (km/h)', 'Chn_shortwave_radiation (W/m²)', 'Delhi_temperature_2m (°C)', 
    'Delhi_relative_humidity_2m (%)', 'Delhi_cloud_cover (%)', 'Delhi_wind_speed_10m (km/h)', 
    'Delhi_shortwave_radiation (W/m²)', 'Hyd_temperature_2m (°C)', 'Hyd_relative_humidity_2m (%)', 
    'Hyd_cloud_cover (%)', 'Hyd_wind_speed_10m (km/h)', 'Hyd_shortwave_radiation (W/m²)', 
    'Mumbai_temperature_2m (°C)', 'Mumbai_relative_humidity_2m (%)', 'Mumbai_cloud_cover (%)', 
    'Mumbai_wind_speed_10m (km/h)', 'Mumbai_shortwave_radiation (W/m²)'
], keep=False)]

print(f"Found {len(duplicates1)} duplicate rows based on these columns.")

print("\n--- Missing Values (Nulls) ---")
# Equivalent to all the SUM(CASE WHEN column IS NULL...) SQL lines
missing_values = df.isnull().sum()
missing_values = missing_values[missing_values > 0] # Show only columns with missing data
print('missing values in the every column is given to zero')


# ==========================================
# 4. BUSINESS MOMENTS (STATISTICAL EDA)
# ==========================================
# To avoid writing 100 queries, we can automate the moments for ALL numeric columns at once.
print("\n--- 1st to 4th Business Moments for all Numerical Columns ---")

# Select only numerical columns for statistical calculation
numeric_cols = df.select_dtypes(include=[np.number]).columns

# Create an empty dictionary to store our stats
stats_dict = {}

for col in numeric_cols:
    stats_dict[col] = {
        'Mean': df[col].mean(),
        'Median': df[col].median(),
        'Mode': df[col].mode()[0] if not df[col].mode().empty else np.nan,
        'Std_Dev': df[col].std(),
        'Variance': df[col].var(),
        'Min': df[col].min(),
        'Max': df[col].max(),
        'Range': df[col].max() - df[col].min(),
        'Skewness': df[col].skew(),
        'Kurtosis': df[col].kurtosis()
    }

# Convert to a DataFrame for a clean, SQL-like table output
business_moments_df = pd.DataFrame(stats_dict).T
(business_moments_df)

# ==========================================
# 5. AUTOMATED PLOTTING (COLUMNS & ROWS)
# ==========================================
sns.set_theme(style="whitegrid")

# -> A. Distribution Plots for EACH Column
import os

print("\n--- Generating Distribution Plots for Every Column ---")

# 1. Define the exact folder name ONCE
folder_name = 'EDA_Plots'

# 2. Check for that specific folder, and create that specific folder
if not os.path.exists(folder_name):
    os.makedirs(folder_name)

for col in numeric_cols:
    fig, ax = plt.subplots(1, 2, figsize=(15, 4))
    
    # Histogram (Shows the distribution of the column)
    sns.histplot(df[col], kde=True, ax=ax[0], color='skyblue')
    ax[0].set_title(f'Distribution of {col}')
    
    # Boxplot (Shows outliers and median)
    sns.boxplot(x=df[col], ax=ax[1], color='lightgreen')
    ax[1].set_title(f'Boxplot of {col}')
    
    plt.tight_layout()
    
    # Clean up filename (added .replace(' ', '_') just in case there are spaces)
    safe_filename = col.replace('/', '_').replace('*', '').replace(' ', '_')
    
    # 3. Use the variable here so it ALWAYS matches the folder you created!
    file_name = f'{folder_name}/Dist_{safe_filename}.png'
    
    plt.savefig(file_name, dpi=300, bbox_inches='tight')
    plt.show()
    
    print("\nAll plots have been saved in the 'EDA_Plots' folder!")
# -> B. Row-by-Row Plotting (Time Series)
# Since plotting every literal row is noisy, we plot the metrics against the index/time.
print("\n--- Generating Time-Series Plots (Row-by-Row Progression) ---")

print("Setting up folders...")
folders = ['EDA_Plots/Univariate', 'EDA_Plots/Bivariate', 'EDA_Plots/Multivariate']
for folder in folders:
    if not os.path.exists(folder):
        os.makedirs(folder)

numeric_cols = df.select_dtypes(include=[np.number]).columns
sns.set_theme(style="whitegrid")

# ==========================================
# 1. UNIVARIATE ANALYSIS (Every Column)
# ==========================================
print(f"Generating Univariate Plots for {len(numeric_cols)} columns...")

for col in numeric_cols:
    fig, axes = plt.subplots(1, 2, figsize=(14, 5))
    
    sns.histplot(df[col], kde=True, color='purple', ax=axes[0])
    axes[0].set_title(f'Distribution of {col}')
    
    sns.boxplot(x=df[col], color='orange', ax=axes[1])
    axes[1].set_title(f'Boxplot of {col}')
    
    plt.tight_layout()
    safe_filename = col.replace('/', '_').replace('*', '').replace(' ', '_')
    plt.savefig(f'EDA_Plots/Univariate/Uni_{safe_filename}.png', dpi=300, bbox_inches='tight')
    
    # CRITICAL: Close the plot so it doesn't eat up all your computer's memory!
    plt.close(fig) 

# ==========================================
# 2. BIVARIATE ANALYSIS (Every Column vs Target)
# ==========================================
# Choose your main variable you want to compare everything else against
target_col = 'MCP (Rs/MWh) *' 

print(f"Generating Bivariate Plots: Everything vs {target_col}...")

if target_col in df.columns:
    for col in numeric_cols:
        if col == target_col:
            continue # Don't plot the target against itself
            
        fig, ax = plt.subplots(figsize=(8, 6))
        
        # Using a scatter plot to see relationships
        sns.scatterplot(x=df[col], y=df[target_col], alpha=0.5, color='teal')
        plt.title(f'{col} vs {target_col}')
        plt.xlabel(col)
        plt.ylabel(target_col)
        
        plt.tight_layout()
        safe_filename = col.replace('/', '_').replace('*', '').replace(' ', '_')
        safe_target = target_col.replace('/', '_').replace('*', '').replace(' ', '_')
        
        plt.savefig(f'EDA_Plots/Bivariate/Bi_{safe_filename}_vs_{safe_target}.png', dpi=300, bbox_inches='tight')
        plt.close(fig)

# ==========================================
# 3. MULTIVARIATE ANALYSIS (Massive Heatmap)
# ==========================================
print("Generating Multivariate Plot (Massive Correlation Heatmap)...")

if len(numeric_cols) > 1:
    # We make the figure HUGE (30x30) so all 75+ columns are readable
    fig, ax = plt.subplots(figsize=(30, 30))
    
    corr_matrix = df[numeric_cols].corr()
    
    # We remove annot=True because 75x75 numbers will look like a black blob. 
    # We use color to spot the trends instead!
    sns.heatmap(corr_matrix, annot=False, cmap='coolwarm', linewidths=0.1)
    plt.title('Complete Correlation Heatmap (All Numeric Variables)', fontsize=24)
    
    plt.tight_layout()
    plt.savefig('EDA_Plots/Multivariate/Multi_Complete_Correlation_Heatmap.png', dpi=400, bbox_inches='tight')
    plt.close(fig)

print("All plots generated and neatly organized into folders!")







