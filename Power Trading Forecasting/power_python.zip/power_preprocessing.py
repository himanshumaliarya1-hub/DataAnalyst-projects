# -*- coding: utf-8 -*-
"""
Created on Tue May  5 14:57:10 2026

@author: Himanshu
"""

import pandas as pd
import numpy as np
import os # Added to help you find the saved file!

# 1. LOAD DATA & CLEAN HEADERS
df = pd.read_csv(r"D:\numpy\power trading analysis\Dataset\New folder\IEX_Weather_final.csv")
df.columns = df.columns.str.strip().str.replace(' ', '_').str.replace('/', '_').str.replace('*', '')

# 2. HANDLE DUPLICATES
print("Removing duplicates...")
initial_rows = len(df)
df.drop_duplicates(subset=['Date', 'Hour', 'Time_Block'], keep='first', inplace=True)
print(f"Dropped {initial_rows - len(df)} duplicate rows.")

# 3. FIX DATA TYPES (DATES & TIME)
print("Formatting dates and times...")

if 'Date' in df.columns:
    # FIX 1: Change format to 'mixed' so Python automatically adapts to your date style!
    df['Date'] = pd.to_datetime(df['Date'], format='mixed', errors='coerce')
    
    # Feature Engineering
    df['Month'] = df['Date'].dt.month
    df['Day_of_Week'] = df['Date'].dt.dayofweek 

# Convert numeric columns to float
numeric_cols = df.columns.difference(['Date', 'Hour', 'Time_Block', 'time'])
for col in numeric_cols:
    df[col] = pd.to_numeric(df[col], errors='coerce')

# 4. HANDLE MISSING VALUES (NULLS)
print("Handling missing data...")

# FIX 2: We removed the 'dropna' line that was deleting your rows.
# Instead, we just let forward-fill patch any missing dates or numbers automatically!
df.ffill(inplace=True) 

# Fill anything left over with the median
df.fillna(df.median(numeric_only=True), inplace=True)

# 5. SAVE THE CLEANED DATASET
cleaned_file_path = 'IEX_Weather_Cleaned.csv'
df.to_csv(cleaned_file_path, index=False)

# Let's get the absolute path so you know EXACTLY where to look
full_save_path = os.path.abspath(cleaned_file_path)

print(f"\n✅ Data processing complete!")
print(f"Final Data Shape: {df.shape[0]} rows, {df.shape[1]} columns")
print(f"📁 You can find your cleaned Excel/CSV file right here: {full_save_path}")
