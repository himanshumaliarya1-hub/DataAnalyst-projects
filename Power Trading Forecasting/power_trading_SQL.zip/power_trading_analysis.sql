create database Power_Trading;
use Power_Trading ;

create table Power_Trading_Forecasting( 
Date varchar(50),
Hour varchar(50),	
Time_Block	varchar(50),
Purchase_Bid_MW varchar(50),
Sell_Bid_MW	varchar(50),	
MCV_MW varchar(50),	
Final_Scheduled_Volume_MW	varchar(50),
MCP_Rs_MWh varchar(50),	
time varchar(50),	
Mundra_temperature_2m 	varchar(50),
Mundra_relative_humidity_2m	varchar(50),
Mundra_cloud_cover 	varchar(50),
Mundra_wind_speed_10m varchar(50),	
Mundra_shortwave_radiation varchar(50),	
RamaGundem_temperature_2m 	varchar(50),
RamaGundem_relative_humidity_2m 	varchar(50),
RamaGundem_cloud_cover 	varchar(50),
RamaGundem_wind_speed_10m  varchar(50),	
RamaGundem_shortwave_radiation  varchar(50),	
Vindhyachal_temperature_2m 	varchar(50),	
Vindhyachal_relative_humidity_2m varchar(50),		
Vindhyachal_cloud_cover 	varchar(50),	
Vindhyachal_wind_speed_10m  varchar(50),		
Vindhyachal_shortwave_radiation 	varchar(50),	
Bhadla_temperature_2m 	varchar(50),	
Bhadla_relative_humidity_2m	varchar(50),	
Bhadla_cloud_cover 	varchar(50),	
Bhadla_wind_speed_10m  varchar(50),		
Bhadla_shortwave_radiation  varchar(50),		
Akaltara_temperature_2m  varchar(50),		
Akaltara_relative_humidity_2m  varchar(50),	
Akaltara_cloud_cover varchar(50),		
Akaltara_wind_speed_10m 	varchar(50),	
Akaltara_shortwave_radiation 	varchar(50),	
Khavda_temperature_2m 	varchar(50),	
Khavda_relative_humidity_2m 	varchar(50),	
Khavda_cloud_cover  varchar(50),	
Khavda_wind_speed_10m  varchar(50),	
Khavda_shortwave_radiation  varchar(50),		
Muppandal_temperature_2m  varchar(50),		
Muppandal_relative_humidity_2m 	varchar(50),	
Muppandal_cloud_cover  varchar(50),		
Muppandal_wind_speed_10m 	varchar(50),	
Muppandal_shortwave_radiation  varchar(50),		
Srisailam_temperature_2m  varchar(50),		
Srisailam_relative_humidity_2m  varchar(50),		
Srisailam_cloud_cover  varchar(50),		
Srisailam_wind_speed_10m 	varchar(50),	
Srisailam_shortwave_radiation  varchar(50),		
Tehri_temperature_2m  varchar(50),		
Tehri_relative_humidity_2m varchar(50),		
Tehri_cloud_cover varchar(50),		
Tehri_wind_speed_10m 	varchar(50),	
Tehri_shortwave_radiation  varchar(50),		
Blr_temperature_2m 	varchar(50),	
Blr_relative_humidity_2m varchar(50),		
Blr_cloud_cover 	varchar(50),	
Blr_wind_speed_10m 	varchar(50),	
Blr_shortwave_radiation 	varchar(50),	
Chn_temperature_2m 	varchar(50),	
Chn_relative_humidity_2m 	varchar(50),	
Chn_cloud_cover 	varchar(50),	
Chn_wind_speed_10m 	varchar(50),	
Chn_shortwave_radiation 	varchar(50),	
Delhi_temperature_2m 	varchar(50),	
Delhi_relative_humidity_2m 	varchar(50),	
Delhi_cloud_cover 	varchar(50),	
Delhi_wind_speed_10m 	varchar(50),	
Delhi_shortwave_radiation 	varchar(50),	
Hyd_temperature_2m 	varchar(50),	
Hyd_relative_humidity_2m 	varchar(50),	
Hyd_cloud_cover 	varchar(50),	
Hyd_wind_speed_10m  varchar(50),		
Hyd_shortwave_radiation 	varchar(50),	
Mumbai_temperature_2m 	varchar(50),	
Mumbai_relative_humidity_2m 	varchar(50),	
Mumbai_cloud_cover 	varchar(50),	
Mumbai_wind_speed_10m varchar(50),		
Mumbai_shortwave_radiation  varchar(50)	

);

SET GLOBAL local_infile  = 1;
LOAD DATA LOCAL INFILE
'C:/ProgramData/MySQL/MySQL Server 9.5/Uploads/IEX_Weather_final.csv'
INTO TABLE Power_Trading_Forecasting
FIELDS TERMINATED BY ','
OPTIONALLY ENCLOSED BY '"'
LINES TERMINATED BY '\n'
IGNORE 1 ROWS;

select * from Power_Trading_Forecasting ;

-- EDA --

-- Total Records--
select count(*) as total_records from Power_Trading_Forecasting;
select* from Power_Trading_Forecasting limit 10;

-- Basic counts--
SELECT
    COUNT(*)                                        AS total_rows,
    COUNT(DISTINCT "Date")                          AS distinct_dates,
    MIN("Date")                                     AS start_date,
    MAX("Date")                                     AS end_date,
    COUNT(DISTINCT "Hour")                          AS distinct_hours,
    COUNT(DISTINCT "Time Block")                    AS distinct_time_blocks
FROM power_trading_forecasting ;

describe Power_Trading_Forecasting;

-- 1) Hour --
select count(*) as total_records from Power_Trading_Forecasting;
select* from Power_Trading_Forecasting limit 10;


-- null values 
select count('hour') as hour;

-- duplicate--
select Date ,Hour, count(*) 
from power_trading_forecasting group by Date ,Hour having count(*) > 1;

-- Missing rows values--
select count(*) as missing_hour 
from power_trading_forcasting where hour is null ;

select min(Hour),max(Hour) from power_trading_forecasting;

-- 2) Time Block --

Select count(*) from power_trading_forecasting where Time_Block;

-- null values--
select count('Time_Block') as Time_block;
-- missing values

select count(*) as missing_time_block
from power_trading_forcasting where Time_Block is null ;

select min(Time_Block),max(Time_Block) from power_trading_forcasting;

-- check the missing values --

select count(*) as missing_hour 
from power_trading_forecasting where hour is null ;
select count(*) as missing_purchase 
from power_trading_forecasting where Purchase_Bid_MW is null ;
select count(*) as missing_time_block
from power_trading_forecasting where Time_Block is null ;
select count(*) as missing_sell_bid
from power_trading_forecasting where Time_Block is null ;
select count(*) as missing_MCV
from power_trading_forecasting where MCV_MW is null ;
select count(*) as missing_scheduled from power_trading_forecasting where Final_Scheduled_Volume_MW is null ;
select count(*) as missing_MCP from power_trading_forecasting where MCP_Rs_MWh is null ;
select count(*) as missing_time from power_trading_forecasting where time is null ;

SELECT
    COUNT(*) AS total_rows,


    -- Mundra--
    SUM(CASE WHEN `Mundra_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS mundra_temp_missing,
    SUM(CASE WHEN `Mundra_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS mundra_humidity_missing,
    SUM(CASE WHEN `Mundra_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS mundra_cloud_missing,
    SUM(CASE WHEN `Mundra_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS mundra_wind_missing,
    SUM(CASE WHEN `Mundra_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS mundra_radiation_missing,

    -- RamaGundem--
    SUM(CASE WHEN `RamaGundem_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS ramagundem_temp_missing,
    SUM(CASE WHEN `RamaGundem_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS ramagundem_humidity_missing,
    SUM(CASE WHEN `RamaGundem_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS ramagundem_cloud_missing,
    SUM(CASE WHEN `RamaGundem_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS ramagundem_wind_missing,
    SUM(CASE WHEN `RamaGundem_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS ramagundem_radiation_missing,

    -- Vindhyachal--
    SUM(CASE WHEN `Vindhyachal_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS vindhyachal_temp_missing,
    SUM(CASE WHEN `Vindhyachal_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS vindhyachal_humidity_missing,
    SUM(CASE WHEN `Vindhyachal_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS vindhyachal_cloud_missing,
    SUM(CASE WHEN `Vindhyachal_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS vindhyachal_wind_missing,
    SUM(CASE WHEN `Vindhyachal_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS vindhyachal_radiation_missing,

    -- Bhadla--
    SUM(CASE WHEN `Bhadla_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS bhadla_temp_missing,
    SUM(CASE WHEN `Bhadla_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS bhadla_humidity_missing,
    SUM(CASE WHEN `Bhadla_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS bhadla_cloud_missing,
    SUM(CASE WHEN `Bhadla_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS bhadla_wind_missing,
    SUM(CASE WHEN `Bhadla_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS bhadla_radiation_missing,

    -- Akaltara
    SUM(CASE WHEN `Akaltara_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS akaltara_temp_missing,
    SUM(CASE WHEN `Akaltara_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS akaltara_humidity_missing,
    SUM(CASE WHEN `Akaltara_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS akaltara_cloud_missing,
    SUM(CASE WHEN `Akaltara_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS akaltara_wind_missing,
    SUM(CASE WHEN `Akaltara_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS akaltara_radiation_missing,

    -- Khavda
    SUM(CASE WHEN `Khavda_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS khavda_temp_missing,
    SUM(CASE WHEN `Khavda_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS khavda_humidity_missing,
    SUM(CASE WHEN `Khavda_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS khavda_cloud_missing,
    SUM(CASE WHEN `Khavda_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS khavda_wind_missing,
    SUM(CASE WHEN `Khavda_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS khavda_radiation_missing,

    -- Muppandal
    SUM(CASE WHEN `Muppandal_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS muppandal_temp_missing,
    SUM(CASE WHEN `Muppandal_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS muppandal_humidity_missing,
    SUM(CASE WHEN `Muppandal_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS muppandal_cloud_missing,
    SUM(CASE WHEN `Muppandal_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS muppandal_wind_missing,
    SUM(CASE WHEN `Muppandal_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS muppandal_radiation_missing,

    -- Srisailam
    SUM(CASE WHEN `Srisailam_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS srisailam_temp_missing,
    SUM(CASE WHEN `Srisailam_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS srisailam_humidity_missing,
    SUM(CASE WHEN `Srisailam_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS srisailam_cloud_missing,
    SUM(CASE WHEN `Srisailam_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS srisailam_wind_missing,
    SUM(CASE WHEN `Srisailam_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS srisailam_radiation_missing,

    -- Tehri
    SUM(CASE WHEN `Tehri_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS tehri_temp_missing,
    SUM(CASE WHEN `Tehri_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS tehri_humidity_missing,
    SUM(CASE WHEN `Tehri_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS tehri_cloud_missing,
    SUM(CASE WHEN `Tehri_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS tehri_wind_missing,
    SUM(CASE WHEN `Tehri_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS tehri_radiation_missing,

    -- Bangalore
    SUM(CASE WHEN `Blr_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS blr_temp_missing,
    SUM(CASE WHEN `Blr_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS blr_humidity_missing,
    SUM(CASE WHEN `Blr_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS blr_cloud_missing,
    SUM(CASE WHEN `Blr_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS blr_wind_missing,
    SUM(CASE WHEN `Blr_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS blr_radiation_missing,
    
    -- Chennai --
	SUM(CASE WHEN `Chn_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS chn_temp_missing,
    SUM(CASE WHEN `Chn_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS chn_humidity_missing,
    SUM(CASE WHEN `Chn_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS chn_cloud_missing,
    SUM(CASE WHEN `Chn_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS chn_wind_missing,
    SUM(CASE WHEN `Chn_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS chn_radiation_missing,
    
    -- Delhi --
	SUM(CASE WHEN `Delhi_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS Dl_temp_missing,
    SUM(CASE WHEN `Delhi_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS DL_humidity_missing,
    SUM(CASE WHEN `Delhi_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS DL_cloud_missing,
    SUM(CASE WHEN `Delhi_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS DL_wind_missing,
    SUM(CASE WHEN `Delhi_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS DL_radiation_missing,
    
    -- Hyderabad--
    
	SUM(CASE WHEN `Hyd_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS TG_temp_missing,
    SUM(CASE WHEN `Hyd_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS TG_humidity_missing,
    SUM(CASE WHEN `Hyd_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS TG_cloud_missing,
    SUM(CASE WHEN `Hyd_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS TG_wind_missing,
    SUM(CASE WHEN `Hyd_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS TG_radiation_missing,
    
    -- Mumbai--
    
	SUM(CASE WHEN `Mumbai_temperature_2m` IS NULL THEN 1 ELSE 0 END) AS MU_temp_missing,
    SUM(CASE WHEN `Mumbai_relative_humidity_2m` IS NULL THEN 1 ELSE 0 END) AS MU_humidity_missing,
    SUM(CASE WHEN `Mumbai_cloud_cover` IS NULL THEN 1 ELSE 0 END) AS MU_cloud_missing,
    SUM(CASE WHEN `Mumbai_wind_speed_10m` IS NULL THEN 1 ELSE 0 END) AS MU_wind_missing,
    SUM(CASE WHEN `Mumbai_shortwave_radiation` IS NULL THEN 1 ELSE 0 END) AS MU_radiation_missing
    
    from power_trading_forecasting;
    -- 1) First Moment
-- Purchase_Bid_MW  (central tendency) --
-- mean--
select avg('Purchase_Bid_MW')as mean_purchase
from power_trading_forecasting;

-- median --

select avg(Purchase_Bid_MW) AS median_price
FROM (SELECT Purchase_Bid_MW,
           ROW_NUMBER() OVER (ORDER BY Purchase_Bid_Mw) AS row_num,
           COUNT(*) OVER () AS total_rows
    FROM power_trading_forecasting
) t
WHERE row_num IN (FLOOR((total_rows + 1)/2), FLOOR((total_rows + 2)/2));

-- mode--
SELECT Purchase_Bid_MW AS mode_purchase
FROM power_trading_forecasting
GROUP BY Purchase_Bid_MW
ORDER BY COUNT(*) DESC
LIMIT 1;
-- 2) 2nd business moments
-- Standard Devitation
SELECT 
    STDDEV(Purchase_Bid_MW) AS std_Purchase
FROM power_trading_forecasting; 

-- Variance --

select variance(Purchase_Bid_MW) from power_trading_forecasting
as var_purchase ;
-- Range -- 

select min(Purchase_Bid_MW),max(Purchase_Bid_MW) from power_trading_forecasting
as range_purchase;
-- 3) business moments --
-- Skewness --
SELECT
(
    SUM(POWER(`Purchase_Bid_MW` - (SELECT AVG(`Purchase_Bid_MW`) FROM power_trading_forecasting), 3)) /
    (COUNT(*) * POWER((SELECT STDDEV(`Purchase_Bid_MW`) FROM power_trading_forecasting), 3))
) AS skewness_purchase_bid
FROM power_trading_forecasting;
    -- 4) business moments--
-- kurtosis--

SELECT
(
   ( SUM(POWER(`Purchase_Bid_MW` - (SELECT AVG(`Purchase_Bid_MW`) FROM power_trading_forecasting), 4)) /
    (COUNT(*) * POWER((SELECT STDDEV(`Purchase_Bid_MW`) FROM power_trading_forecasting), 4))
)-3
) AS Kurtosis_purchase_bid
FROM power_trading_forecasting;
    
-- 1) First Moment
-- sell_Bid  (central tendency) --
-- mean--
select avg('Sell_Bid_MW')as mean_sell_bid
from power_trading_forecasting;

-- median --

select avg(Sell_Bid_MW) AS median_sell
FROM (SELECT Sell_Bid_MW,
           ROW_NUMBER() OVER (ORDER BY Sell_Bid_MW) AS row_num,
           COUNT(*) OVER () AS total_rows
    FROM power_trading_forecasting
) t
WHERE row_num IN (FLOOR((total_rows + 1)/2), FLOOR((total_rows + 2)/2));

-- mode--
SELECT Sell_Bid_MW AS mode_Sell
FROM power_trading_forecasting
GROUP BY Sell_Bid_MW
ORDER BY COUNT(*) DESC
LIMIT 1;
-- 2) 2nd business moments
-- Standard Devitation
SELECT 
    STDDEV(Sell_Bid_MW) AS std_Sell
FROM power_trading_forecasting; 

-- Variance --

select variance(Sell_Bid_MW) from power_trading_forecasting
as var_Sell_Bid_MW ;
-- Range -- 

select min(Sell_Bid_MW),max(Sell_Bid_MW) from power_trading_forecasting
as range_Sell;
-- 3) business moments --
-- Skewness --
SELECT
(
    SUM(POWER(`Sell_Bid_MW` - (SELECT AVG(`Sell_Bid_MW`) FROM power_trading_forecasting), 3)) /
    (COUNT(*) * POWER((SELECT STDDEV(`Sell_Bid_MW`) FROM power_trading_forecasting), 3))
) AS skewness_Sell_bid
FROM power_trading_forecasting;
    -- 4) business moments--
-- kurtosis--

SELECT
(
   ( SUM(POWER(`Sell_Bid_MW` - (SELECT AVG(`Sell_Bid_MW`) FROM power_trading_forecasting), 4)) /
    (COUNT(*) * POWER((SELECT STDDEV(`Sell_Bid_MW`) FROM power_trading_forecasting), 4))
)-3
) AS Kurtosis_Sell_Bid
FROM power_trading_forecasting;

-- #3. MCV (MW)
-- =========================================

-- Mean
SELECT AVG(`MCV_MW`) AS mean_mcv
FROM power_trading_forecasting;

-- Median
SELECT `MCV_MW` AS median_mcv
FROM (
    SELECT `MCV_MW`,
           ROW_NUMBER() OVER (ORDER BY `MCV_MW`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `MCV_MW` AS mode_mcv
FROM (
    SELECT `MCV_MW`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `MCV_MW`
    ORDER BY frequency DESC
    LIMIT 1
) t;

-- Standard Deviation
SELECT STDDEV(`MCV_MW`) AS stddev_mcv
FROM power_trading_forecasting;

-- Variance
SELECT VARIANCE(`MCV_MW`) AS variance_mcv
FROM power_trading_forecasting;

-- Range
SELECT MAX(`MCV_MW`) AS max_mcv,
       MIN(`MCV_MW`) AS min_mcv
FROM power_trading_forecasting;

-- Skewness
SELECT
(
    SUM(POWER(`MCV_MW` - (SELECT AVG(`MCV_MW`) FROM power_trading_forecasting), 3)) /
    (COUNT(*) * POWER((SELECT STDDEV(`MCV_MW`) FROM power_trading_forecasting), 3))
) AS skewness_mcv
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
    (
        SUM(POWER(`MCV_MW` - (SELECT AVG(`MCV_MW`) FROM power_trading_forecasting), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(`MCV_MW`) FROM power_trading_forecasting), 4))
    ) - 3
) AS kurtosis_mcv
FROM power_trading_forecasting;


-- =========================================
-- #4. Final Scheduled Volume (MW)
-- =========================================

-- Mean
SELECT AVG(`Final_Scheduled_Volume_MW`) AS mean_final_scheduled_volume
FROM power_trading_forecasting;

-- Median
SELECT `Final_Scheduled_Volume_MW` AS median_final_scheduled_volume
FROM (
    SELECT `Final_Scheduled_Volume_MW`,
           ROW_NUMBER() OVER (ORDER BY `Final_Scheduled_Volume_MW`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Final_Scheduled_Volume_MW` AS mode_final_scheduled_volume
FROM (
    SELECT `Final_Scheduled_Volume_MW`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Final_Scheduled_Volume_MW`
    ORDER BY frequency DESC
    LIMIT 1
) t;

-- Standard Deviation
SELECT STDDEV(`Final_Scheduled_Volume_MW`) AS stddev_final_scheduled_volume
FROM power_trading_forecasting;

-- Variance
SELECT VARIANCE(`Final_Scheduled_Volume_MW`) AS variance_final_scheduled_volume
FROM power_trading_forecasting;

-- Range
SELECT MAX(`Final_Scheduled_Volume_MW`) AS max_scheduled_volume,
       MIN(`Final_Scheduled_Volume_MW`) AS min_scheduled_volume
FROM power_trading_forecasting;

-- Skewness
SELECT
(
    SUM(POWER(`Final_Scheduled_Volume_MW` -
    (SELECT AVG(`Final_Scheduled_Volume_MW`) FROM power_trading_forecasting), 3)) /
    (COUNT(*) * POWER((SELECT STDDEV(`Final_Scheduled_Volume_MW`) FROM power_trading_forecasting), 3))
) AS skewness_final_scheduled_volume
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
    (
        SUM(POWER(`Final_Scheduled_Volume_MW` -
        (SELECT AVG(`Final_Scheduled_Volume_MW`) FROM power_trading_forecasting), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(`Final_Scheduled_Volume_MW`) FROM power_trading_forecasting), 4))
    ) - 3
) AS kurtosis_final_scheduled_volume
FROM power_trading_forecasting;


-- =========================================
-- #5. MCP (Rs/MWh)
-- =========================================

-- Mean
SELECT AVG(`MCP_Rs_MWh`) AS mean_mcp
FROM power_trading_forecasting;

-- Median
SELECT `MCP_Rs_MWh` AS median_mcp
FROM (
    SELECT `MCP_Rs_MWh`,
           ROW_NUMBER() OVER (ORDER BY `MCP_Rs_MWh`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `MCP_Rs_MWh` AS mode_mcp
FROM (
    SELECT `MCP_Rs_MWh`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `MCP_Rs_MWh`
    ORDER BY frequency DESC
    LIMIT 1
) t;

-- Standard Deviation
SELECT STDDEV(`MCP_Rs_MWh`) AS stddev_mcp
FROM power_trading_forecasting;

-- Variance
SELECT VARIANCE(`MCP_Rs_MWh`) AS variance_mcp
FROM power_trading_forecasting;

-- Range
SELECT MAX(`MCP_Rs_MWh`) AS max_mcp,
       MIN(`MCP_Rs_MWh`) AS min_mcp
FROM power_trading_forecasting;

-- Skewness
SELECT
(
    SUM(POWER(`MCP_Rs_MWh` - (SELECT AVG(`MCP_Rs_MWh`) FROM power_trading_forecasting), 3)) /
    (COUNT(*) * POWER((SELECT STDDEV(`MCP_Rs_MWh`) FROM power_trading_forecasting), 3))
) AS skewness_mcp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
    (
        SUM(POWER(`MCP_Rs_MWh` - (SELECT AVG(`MCP_Rs_MWh`) FROM power_trading_forecasting), 4)) /
        (COUNT(*) * POWER((SELECT STDDEV(`MCP_Rs_MWh`) FROM power_trading_forecasting), 4))
    ) - 3
) AS kurtosis_mcp
FROM power_trading_forecasting;


-- =========================================
-- DELHI TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Delhi_temperature_2m`) AS mean_delhi_temp
FROM power_trading_forecasting;

-- Median
SELECT `Delhi_temperature_2m` AS median_delhi_temp
FROM (
    SELECT `Delhi_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Delhi_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Delhi_temperature_2m` AS mode_delhi_temp
FROM (
    SELECT `Delhi_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Delhi_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

-- Standard Deviation
SELECT STDDEV(`Delhi_temperature_2m`) AS stddev_delhi_temp
FROM power_trading_forecasting;

-- Variance
SELECT VARIANCE(`Delhi_temperature_2m`) AS variance_delhi_temp
FROM power_trading_forecasting;

-- Range
SELECT MAX(`Delhi_temperature_2m`) AS max_delhi_temp,
       MIN(`Delhi_temperature_2m`) AS min_delhi_temp
FROM power_trading_forecasting;

-- Skewness
SELECT
(SUM(POWER(`Delhi_temperature_2m` - (SELECT AVG(`Delhi_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Delhi_temperature_2m`) FROM power_trading_forecasting), 3)))
AS skewness_delhi_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
((SUM(POWER(`Delhi_temperature_2m` - (SELECT AVG(`Delhi_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Delhi_temperature_2m`) FROM power_trading_forecasting), 4))) - 3)
AS kurtosis_delhi_temp
FROM power_trading_forecasting;


-- =========================================
-- DELHI HUMIDITY (%)
-- =========================================

SELECT AVG(`Delhi_relative_humidity_2m`) AS mean_delhi_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Delhi_relative_humidity_2m`) AS stddev_delhi_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Delhi_relative_humidity_2m`) AS variance_delhi_humidity FROM power_trading_forecasting;
SELECT MAX(`Delhi_relative_humidity_2m`) AS max_delhi_humidity,
       MIN(`Delhi_relative_humidity_2m`) AS min_delhi_humidity FROM power_trading_forecasting;


-- =========================================
-- DELHI CLOUD COVER (%)
-- =========================================

SELECT AVG(`Delhi_cloud_cover`) AS mean_delhi_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Delhi_cloud_cover`) AS stddev_delhi_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Delhi_cloud_cover`) AS variance_delhi_cloud FROM power_trading_forecasting;
SELECT MAX(`Delhi_cloud_cover`) AS max_delhi_cloudcover,
       MIN(`Delhi_cloud_cover`) AS min_delhi_cloudcover FROM power_trading_forecasting;


-- =========================================
-- DELHI WIND SPEED (km/h)
-- =========================================

-- Mean
SELECT AVG(`Delhi_wind_speed_10m`) AS mean_delhi_wind FROM power_trading_forecasting;

-- Median
SELECT `Delhi_wind_speed_10m` AS median_delhi_wind
FROM (
    SELECT `Delhi_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Delhi_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Delhi_wind_speed_10m`) AS stddev_delhi_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Delhi_wind_speed_10m`) AS variance_delhi_wind FROM power_trading_forecasting;
SELECT MAX(`Delhi_wind_speed_10m`) AS max_delhi_windspeed,
       MIN(`Delhi_wind_speed_10m`) AS min_delhi_windspeed FROM power_trading_forecasting;


-- =========================================
-- DELHI SOLAR RADIATION (W/m²)
-- =========================================

-- Mean
SELECT AVG(`Delhi_shortwave_radiation`) AS mean_delhi_radiation FROM power_trading_forecasting;

-- Median
SELECT `Delhi_shortwave_radiation` AS median_delhi_radiation
FROM (
    SELECT `Delhi_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Delhi_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Delhi_shortwave_radiation`) AS stddev_delhi_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Delhi_shortwave_radiation`) AS variance_delhi_radiation FROM power_trading_forecasting;
SELECT MAX(`Delhi_shortwave_radiation`) AS max_delhi_radiation,
       MIN(`Delhi_shortwave_radiation`) AS min_delhi_radiation FROM power_trading_forecasting;


-- =========================================
-- MUMBAI TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Mumbai_temperature_2m`) AS mean_mumbai_temp FROM power_trading_forecasting;

-- Median
SELECT `Mumbai_temperature_2m` AS median_mumbai_temp
FROM (
    SELECT `Mumbai_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Mumbai_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Mumbai_temperature_2m` AS mode_mumbai_temp
FROM (
    SELECT `Mumbai_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Mumbai_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Mumbai_temperature_2m`) AS stddev_mumbai_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Mumbai_temperature_2m`) AS variance_mumbai_temp FROM power_trading_forecasting;
SELECT MAX(`Mumbai_temperature_2m`) AS max_mumbai_temp,
       MIN(`Mumbai_temperature_2m`) AS min_mumbai_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Mumbai_temperature_2m` -
(SELECT AVG(`Mumbai_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Mumbai_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_mumbai_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Mumbai_temperature_2m` -
(SELECT AVG(`Mumbai_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Mumbai_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_mumbai_temp
FROM power_trading_forecasting;


-- =========================================
-- MUMBAI HUMIDITY (%)
-- =========================================

SELECT AVG(`Mumbai_relative_humidity_2m`) AS mean_mumbai_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Mumbai_relative_humidity_2m`) AS stddev_mumbai_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Mumbai_relative_humidity_2m`) AS variance_mumbai_humidity FROM power_trading_forecasting;
SELECT MAX(`Mumbai_relative_humidity_2m`) AS max_mumbai_humidity,
       MIN(`Mumbai_relative_humidity_2m`) AS min_mumbai_humidity FROM power_trading_forecasting;


-- =========================================
-- MUMBAI CLOUD COVER (%)
-- =========================================

SELECT AVG(`Mumbai_cloud_cover`) AS mean_mumbai_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Mumbai_cloud_cover`) AS stddev_mumbai_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Mumbai_cloud_cover`) AS variance_mumbai_cloud FROM power_trading_forecasting;
SELECT MAX(`Mumbai_cloud_cover`) AS max_mumbai_cloudcover,
       MIN(`Mumbai_cloud_cover`) AS min_mumbai_cloudcover FROM power_trading_forecasting;


-- =========================================
-- MUMBAI WIND SPEED (km/h)
-- =========================================

-- Mean
SELECT AVG(`Mumbai_wind_speed_10m`) AS mean_mumbai_wind FROM power_trading_forecasting;

-- Median
SELECT `Mumbai_wind_speed_10m` AS median_mumbai_wind
FROM (
    SELECT `Mumbai_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Mumbai_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Mumbai_wind_speed_10m`) AS stddev_mumbai_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Mumbai_wind_speed_10m`) AS variance_mumbai_wind FROM power_trading_forecasting;
SELECT MAX(`Mumbai_wind_speed_10m`) AS max_mumbai_windspeed,
       MIN(`Mumbai_wind_speed_10m`) AS min_mumbai_windspeed FROM power_trading_forecasting;


-- =========================================
-- MUMBAI SOLAR RADIATION (W/m²)
-- =========================================

-- Mean
SELECT AVG(`Mumbai_shortwave_radiation`) AS mean_mumbai_radiation FROM power_trading_forecasting;

-- Median
SELECT `Mumbai_shortwave_radiation` AS median_mumbai_radiation
FROM (
    SELECT `Mumbai_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Mumbai_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Mumbai_shortwave_radiation`) AS stddev_mumbai_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Mumbai_shortwave_radiation`) AS variance_mumbai_radiation FROM power_trading_forecasting;
SELECT MAX(`Mumbai_shortwave_radiation`) AS max_mumbai_radiation,
       MIN(`Mumbai_shortwave_radiation`) AS min_mumbai_radiation FROM power_trading_forecasting;


-- =========================================
-- HYDERABAD TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Hyd_temperature_2m`) AS mean_hyd_temp FROM power_trading_forecasting;

-- Median
SELECT `Hyd_temperature_2m` AS median_hyd_temp
FROM (
    SELECT `Hyd_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Hyd_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Hyd_temperature_2m` AS mode_hyd_temp
FROM (
    SELECT `Hyd_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Hyd_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Hyd_temperature_2m`) AS stddev_hyd_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Hyd_temperature_2m`) AS variance_hyd_temp FROM power_trading_forecasting;
SELECT MAX(`Hyd_temperature_2m`) AS max_hyd_temp,
       MIN(`Hyd_temperature_2m`) AS min_hyd_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Hyd_temperature_2m` -
(SELECT AVG(`Hyd_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Hyd_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_hyd_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Hyd_temperature_2m` -
(SELECT AVG(`Hyd_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Hyd_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_hyd_temp
FROM power_trading_forecasting;


-- =========================================
-- HYDERABAD HUMIDITY (%)
-- =========================================

SELECT AVG(`Hyd_relative_humidity_2m`) AS mean_hyd_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Hyd_relative_humidity_2m`) AS stddev_hyd_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Hyd_relative_humidity_2m`) AS variance_hyd_humidity FROM power_trading_forecasting;
SELECT MAX(`Hyd_relative_humidity_2m`) AS max_hyd_humidity,
       MIN(`Hyd_relative_humidity_2m`) AS min_hyd_humidity FROM power_trading_forecasting;


-- =========================================
-- HYDERABAD CLOUD COVER (%)
-- =========================================

SELECT AVG(`Hyd_cloud_cover`) AS mean_hyd_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Hyd_cloud_cover`) AS stddev_hyd_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Hyd_cloud_cover`) AS variance_hyd_cloud FROM power_trading_forecasting;
SELECT MAX(`Hyd_cloud_cover`) AS max_hyd_cloudcover,
       MIN(`Hyd_cloud_cover`) AS min_hyd_cloudcover FROM power_trading_forecasting;


-- =========================================
-- HYDERABAD WIND SPEED (km/h)
-- =========================================

-- Mean
SELECT AVG(`Hyd_wind_speed_10m`) AS mean_hyd_wind FROM power_trading_forecasting;

-- Median
SELECT `Hyd_wind_speed_10m` AS median_hyd_wind
FROM (
    SELECT `Hyd_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Hyd_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Hyd_wind_speed_10m`) AS stddev_hyd_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Hyd_wind_speed_10m`) AS variance_hyd_wind FROM power_trading_forecasting;
SELECT MAX(`Hyd_wind_speed_10m`) AS max_hyd_windspeed,
       MIN(`Hyd_wind_speed_10m`) AS min_hyd_windspeed FROM power_trading_forecasting;


-- =========================================
-- HYDERABAD SOLAR RADIATION (W/m²)
-- =========================================

-- Mean
SELECT AVG(`Hyd_shortwave_radiation`) AS mean_hyd_radiation FROM power_trading_forecasting;

-- Median
SELECT `Hyd_shortwave_radiation` AS median_hyd_radiation
FROM (
    SELECT `Hyd_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Hyd_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Hyd_shortwave_radiation`) AS stddev_hyd_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Hyd_shortwave_radiation`) AS variance_hyd_radiation FROM power_trading_forecasting;
SELECT MAX(`Hyd_shortwave_radiation`) AS max_hyd_radiation,
       MIN(`Hyd_shortwave_radiation`) AS min_hyd_radiation FROM power_trading_forecasting;


-- =========================================
-- CHENNAI TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Chn_temperature_2m`) AS mean_chn_temp FROM power_trading_forecasting;

-- Median
SELECT `Chn_temperature_2m` AS median_chn_temp
FROM (
    SELECT `Chn_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Chn_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Chn_temperature_2m` AS mode_chn_temp
FROM (
    SELECT `Chn_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Chn_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Chn_temperature_2m`) AS stddev_chn_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Chn_temperature_2m`) AS variance_chn_temp FROM power_trading_forecasting;
SELECT MAX(`Chn_temperature_2m`) AS max_chn_temp,
       MIN(`Chn_temperature_2m`) AS min_chn_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Chn_temperature_2m` -
(SELECT AVG(`Chn_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Chn_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_chn_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Chn_temperature_2m` -
(SELECT AVG(`Chn_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Chn_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_chn_temp
FROM power_trading_forecasting;


-- =========================================
-- CHENNAI HUMIDITY (%)
-- =========================================

SELECT AVG(`Chn_relative_humidity_2m`) AS mean_chn_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Chn_relative_humidity_2m`) AS stddev_chn_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Chn_relative_humidity_2m`) AS variance_chn_humidity FROM power_trading_forecasting;
SELECT MAX(`Chn_relative_humidity_2m`) AS max_chn_humidity,
       MIN(`Chn_relative_humidity_2m`) AS min_chn_humidity FROM power_trading_forecasting;


-- =========================================
-- CHENNAI CLOUD COVER (%)
-- =========================================

SELECT AVG(`Chn_cloud_cover`) AS mean_chn_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Chn_cloud_cover`) AS stddev_chn_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Chn_cloud_cover`) AS variance_chn_cloud FROM power_trading_forecasting;
SELECT MAX(`Chn_cloud_cover`) AS max_chn_cloudcover,
       MIN(`Chn_cloud_cover`) AS min_chn_cloudcover FROM power_trading_forecasting;


-- =========================================
-- CHENNAI WIND SPEED (km/h)
-- =========================================

SELECT AVG(`Chn_wind_speed_10m`) AS mean_chn_wind FROM power_trading_forecasting;

SELECT `Chn_wind_speed_10m` AS median_chn_wind
FROM (
    SELECT `Chn_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Chn_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Chn_wind_speed_10m`) AS stddev_chn_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Chn_wind_speed_10m`) AS variance_chn_wind FROM power_trading_forecasting;
SELECT MAX(`Chn_wind_speed_10m`) AS max_chn_windspeed,
       MIN(`Chn_wind_speed_10m`) AS min_chn_windspeed FROM power_trading_forecasting;


-- =========================================
-- CHENNAI SOLAR RADIATION (W/m²)
-- =========================================

SELECT AVG(`Chn_shortwave_radiation`) AS mean_chn_radiation FROM power_trading_forecasting;

SELECT `Chn_shortwave_radiation` AS median_chn_radiation
FROM (
    SELECT `Chn_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Chn_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Chn_shortwave_radiation`) AS stddev_chn_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Chn_shortwave_radiation`) AS variance_chn_radiation FROM power_trading_forecasting;
SELECT MAX(`Chn_shortwave_radiation`) AS max_chn_radiation,
       MIN(`Chn_shortwave_radiation`) AS min_chn_radiation FROM power_trading_forecasting;


-- =========================================
-- BHADLA TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Bhadla_temperature_2m`) AS mean_bhadla_temp FROM power_trading_forecasting;

-- Median
SELECT `Bhadla_temperature_2m` AS median_bhadla_temp
FROM (
    SELECT `Bhadla_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Bhadla_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Bhadla_temperature_2m` AS mode_bhadla_temp
FROM (
    SELECT `Bhadla_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Bhadla_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Bhadla_temperature_2m`) AS stddev_bhadla_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Bhadla_temperature_2m`) AS variance_bhadla_temp FROM power_trading_forecasting;
SELECT MAX(`Bhadla_temperature_2m`) AS max_bhadla_temp,
       MIN(`Bhadla_temperature_2m`) AS min_bhadla_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Bhadla_temperature_2m` -
(SELECT AVG(`Bhadla_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Bhadla_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_bhadla_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Bhadla_temperature_2m` -
(SELECT AVG(`Bhadla_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Bhadla_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_bhadla_temp
FROM power_trading_forecasting;


-- =========================================
-- BHADLA HUMIDITY (%)
-- =========================================

SELECT AVG(`Bhadla_relative_humidity_2m`) AS mean_bhadla_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Bhadla_relative_humidity_2m`) AS stddev_bhadla_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Bhadla_relative_humidity_2m`) AS variance_bhadla_humidity FROM power_trading_forecasting;
SELECT MAX(`Bhadla_relative_humidity_2m`) AS max_bhadla_humidity,
       MIN(`Bhadla_relative_humidity_2m`) AS min_bhadla_humidity FROM power_trading_forecasting;


-- =========================================
-- BHADLA CLOUD COVER (%)
-- =========================================

SELECT AVG(`Bhadla_cloud_cover`) AS mean_bhadla_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Bhadla_cloud_cover`) AS stddev_bhadla_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Bhadla_cloud_cover`) AS variance_bhadla_cloud FROM power_trading_forecasting;
SELECT MAX(`Bhadla_cloud_cover`) AS max_bhadla_cloudcover,
       MIN(`Bhadla_cloud_cover`) AS min_bhadla_cloudcover FROM power_trading_forecasting;


-- =========================================
-- BHADLA WIND SPEED (km/h)
-- =========================================

-- Mean
SELECT AVG(`Bhadla_wind_speed_10m`) AS mean_bhadla_wind FROM power_trading_forecasting;

-- Median
SELECT `Bhadla_wind_speed_10m` AS median_bhadla_wind
FROM (
    SELECT `Bhadla_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Bhadla_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Bhadla_wind_speed_10m`) AS stddev_bhadla_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Bhadla_wind_speed_10m`) AS variance_bhadla_wind FROM power_trading_forecasting;
SELECT MAX(`Bhadla_wind_speed_10m`) AS max_bhadla_windspeed,
       MIN(`Bhadla_wind_speed_10m`) AS min_bhadla_windspeed FROM power_trading_forecasting;


-- =========================================
-- BHADLA SOLAR RADIATION (W/m²)
-- =========================================

-- Mean
SELECT AVG(`Bhadla_shortwave_radiation`) AS mean_bhadla_radiation FROM power_trading_forecasting;

-- Median
SELECT `Bhadla_shortwave_radiation` AS median_bhadla_radiation
FROM (
    SELECT `Bhadla_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Bhadla_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Bhadla_shortwave_radiation`) AS stddev_bhadla_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Bhadla_shortwave_radiation`) AS variance_bhadla_radiation FROM power_trading_forecasting;
SELECT MAX(`Bhadla_shortwave_radiation`) AS max_bhadla_radiation,
       MIN(`Bhadla_shortwave_radiation`) AS min_bhadla_radiation FROM power_trading_forecasting;


-- =========================================
-- BANGALORE (BLR) TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Blr_temperature_2m`) AS mean_blr_temp FROM power_trading_forecasting;

-- Median
SELECT `Blr_temperature_2m` AS median_blr_temp
FROM (
    SELECT `Blr_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Blr_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Blr_temperature_2m` AS mode_blr_temp
FROM (
    SELECT `Blr_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Blr_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Blr_temperature_2m`) AS stddev_blr_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Blr_temperature_2m`) AS variance_blr_temp FROM power_trading_forecasting;
SELECT MAX(`Blr_temperature_2m`) AS max_blr_temp,
       MIN(`Blr_temperature_2m`) AS min_blr_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Blr_temperature_2m` -
(SELECT AVG(`Blr_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Blr_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_blr_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Blr_temperature_2m` -
(SELECT AVG(`Blr_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Blr_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_blr_temp
FROM power_trading_forecasting;


-- =========================================
-- BANGALORE (BLR) HUMIDITY (%)
-- =========================================

SELECT AVG(`Blr_relative_humidity_2m`) AS mean_blr_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Blr_relative_humidity_2m`) AS stddev_blr_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Blr_relative_humidity_2m`) AS variance_blr_humidity FROM power_trading_forecasting;
SELECT MAX(`Blr_relative_humidity_2m`) AS max_blr_humidity,
       MIN(`Blr_relative_humidity_2m`) AS min_blr_humidity FROM power_trading_forecasting;


-- =========================================
-- BANGALORE (BLR) CLOUD COVER (%)
-- =========================================

SELECT AVG(`Blr_cloud_cover`) AS mean_blr_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Blr_cloud_cover`) AS stddev_blr_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Blr_cloud_cover`) AS variance_blr_cloud FROM power_trading_forecasting;
SELECT MAX(`Blr_cloud_cover`) AS max_blr_cloudcover,
       MIN(`Blr_cloud_cover`) AS min_blr_cloudcover FROM power_trading_forecasting;


-- =========================================
-- BANGALORE (BLR) WIND SPEED (km/h)
-- =========================================

SELECT AVG(`Blr_wind_speed_10m`) AS mean_blr_wind FROM power_trading_forecasting;

SELECT `Blr_wind_speed_10m` AS median_blr_wind
FROM (
    SELECT `Blr_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Blr_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Blr_wind_speed_10m`) AS stddev_blr_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Blr_wind_speed_10m`) AS variance_blr_wind FROM power_trading_forecasting;
SELECT MAX(`Blr_wind_speed_10m`) AS max_blr_windspeed,
       MIN(`Blr_wind_speed_10m`) AS min_blr_windspeed FROM power_trading_forecasting;



-- BANGALORE (BLR) SOLAR RADIATION (W/m²)

SELECT AVG(`Blr_shortwave_radiation`) AS mean_blr_radiation FROM power_trading_forecasting;

SELECT `Blr_shortwave_radiation` AS median_blr_radiation
FROM (
    SELECT `Blr_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Blr_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Blr_shortwave_radiation`) AS stddev_blr_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Blr_shortwave_radiation`) AS variance_blr_radiation FROM power_trading_forecasting;
SELECT MAX(`Blr_shortwave_radiation`) AS max_blr_radiation,
       MIN(`Blr_shortwave_radiation`) AS min_blr_radiation FROM power_trading_forecasting;


-- =========================================
-- TEHRI TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Tehri_temperature_2m`) AS mean_tehri_temp FROM power_trading_forecasting;

-- Median
SELECT `Tehri_temperature_2m` AS median_tehri_temp
FROM (
    SELECT `Tehri_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Tehri_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Tehri_temperature_2m` AS mode_tehri_temp
FROM (
    SELECT `Tehri_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Tehri_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Tehri_temperature_2m`) AS stddev_tehri_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Tehri_temperature_2m`) AS variance_tehri_temp FROM power_trading_forecasting;
SELECT MAX(`Tehri_temperature_2m`) AS max_tehri_temp,
       MIN(`Tehri_temperature_2m`) AS min_tehri_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Tehri_temperature_2m` -
(SELECT AVG(`Tehri_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Tehri_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_tehri_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Tehri_temperature_2m` -
(SELECT AVG(`Tehri_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Tehri_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_tehri_temp
FROM power_trading_forecasting;


-- =========================================
-- TEHRI HUMIDITY (%)
-- =========================================

SELECT AVG(`Tehri_relative_humidity_2m`) AS mean_tehri_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Tehri_relative_humidity_2m`) AS stddev_tehri_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Tehri_relative_humidity_2m`) AS variance_tehri_humidity FROM power_trading_forecasting;
SELECT MAX(`Tehri_relative_humidity_2m`) AS max_tehri_humidity,
       MIN(`Tehri_relative_humidity_2m`) AS min_tehri_humidity FROM power_trading_forecasting;


-- =========================================
-- TEHRI CLOUD COVER (%)
-- =========================================

SELECT AVG(`Tehri_cloud_cover`) AS mean_tehri_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Tehri_cloud_cover`) AS stddev_tehri_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Tehri_cloud_cover`) AS variance_tehri_cloud FROM power_trading_forecasting;
SELECT MAX(`Tehri_cloud_cover`) AS max_tehri_cloudcover,
       MIN(`Tehri_cloud_cover`) AS min_tehri_cloudcover FROM power_trading_forecasting;


-- =========================================
-- TEHRI WIND SPEED (km/h)
-- =========================================

SELECT AVG(`Tehri_wind_speed_10m`) AS mean_tehri_wind FROM power_trading_forecasting;

SELECT `Tehri_wind_speed_10m` AS median_tehri_wind
FROM (
    SELECT `Tehri_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Tehri_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Tehri_wind_speed_10m`) AS stddev_tehri_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Tehri_wind_speed_10m`) AS variance_tehri_wind FROM power_trading_forecasting;
SELECT MAX(`Tehri_wind_speed_10m`) AS max_tehri_windspeed,
       MIN(`Tehri_wind_speed_10m`) AS min_tehri_windspeed FROM power_trading_forecasting;


-- =========================================
-- TEHRI SOLAR RADIATION (W/m²)
-- =========================================

SELECT AVG(`Tehri_shortwave_radiation`) AS mean_tehri_radiation FROM power_trading_forecasting;

SELECT `Tehri_shortwave_radiation` AS median_tehri_radiation
FROM (
    SELECT `Tehri_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Tehri_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Tehri_shortwave_radiation`) AS stddev_tehri_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Tehri_shortwave_radiation`) AS variance_tehri_radiation FROM power_trading_forecasting;
SELECT MAX(`Tehri_shortwave_radiation`) AS max_tehri_radiation,
       MIN(`Tehri_shortwave_radiation`) AS min_tehri_radiation FROM power_trading_forecasting;


-- =========================================
-- SRISAILAM TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Srisailam_temperature_2m`) AS mean_srisailam_temp FROM power_trading_forecasting;

-- Median
SELECT `Srisailam_temperature_2m` AS median_srisailam_temp
FROM (
    SELECT `Srisailam_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Srisailam_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Srisailam_temperature_2m` AS mode_srisailam_temp
FROM (
    SELECT `Srisailam_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Srisailam_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Srisailam_temperature_2m`) AS stddev_srisailam_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Srisailam_temperature_2m`) AS variance_srisailam_temp FROM power_trading_forecasting;
SELECT MAX(`Srisailam_temperature_2m`) AS max_srisailam_temp,
       MIN(`Srisailam_temperature_2m`) AS min_srisailam_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Srisailam_temperature_2m` -
(SELECT AVG(`Srisailam_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Srisailam_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_srisailam_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Srisailam_temperature_2m` -
(SELECT AVG(`Srisailam_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Srisailam_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_srisailam_temp
FROM power_trading_forecasting;


-- =========================================
-- SRISAILAM HUMIDITY (%)
-- =========================================

SELECT AVG(`Srisailam_relative_humidity_2m`) AS mean_srisailam_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Srisailam_relative_humidity_2m`) AS stddev_srisailam_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Srisailam_relative_humidity_2m`) AS variance_srisailam_humidity FROM power_trading_forecasting;
SELECT MAX(`Srisailam_relative_humidity_2m`) AS max_srisailam_humidity,
       MIN(`Srisailam_relative_humidity_2m`) AS min_srisailam_humidity FROM power_trading_forecasting;


-- =========================================
-- SRISAILAM CLOUD COVER (%)
-- =========================================

SELECT AVG(`Srisailam_cloud_cover`) AS mean_srisailam_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Srisailam_cloud_cover`) AS stddev_srisailam_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Srisailam_cloud_cover`) AS variance_srisailam_cloud FROM power_trading_forecasting;
SELECT MAX(`Srisailam_cloud_cover`) AS max_srisailam_cloudcover,
       MIN(`Srisailam_cloud_cover`) AS min_srisailam_cloudcover FROM power_trading_forecasting;


-- =========================================
-- SRISAILAM WIND SPEED (km/h)
-- =========================================

SELECT AVG(`Srisailam_wind_speed_10m`) AS mean_srisailam_wind FROM power_trading_forecasting;

SELECT `Srisailam_wind_speed_10m` AS median_srisailam_wind
FROM (
    SELECT `Srisailam_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Srisailam_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Srisailam_wind_speed_10m`) AS stddev_srisailam_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Srisailam_wind_speed_10m`) AS variance_srisailam_wind FROM power_trading_forecasting;
SELECT MAX(`Srisailam_wind_speed_10m`) AS max_srisailam_windspeed,
       MIN(`Srisailam_wind_speed_10m`) AS min_srisailam_windspeed FROM power_trading_forecasting;


-- =========================================
-- SRISAILAM SOLAR RADIATION (W/m²)
-- =========================================

SELECT AVG(`Srisailam_shortwave_radiation`) AS mean_srisailam_radiation FROM power_trading_forecasting;

SELECT `Srisailam_shortwave_radiation` AS median_srisailam_radiation
FROM (
    SELECT `Srisailam_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Srisailam_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Srisailam_shortwave_radiation`) AS stddev_srisailam_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Srisailam_shortwave_radiation`) AS variance_srisailam_radiation FROM power_trading_forecasting;
SELECT MAX(`Srisailam_shortwave_radiation`) AS max_srisailam_radiation,
       MIN(`Srisailam_shortwave_radiation`) AS min_srisailam_radiation FROM power_trading_forecasting;


-- =========================================
-- MUPPANDAL TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Muppandal_temperature_2m`) AS mean_muppandal_temp FROM power_trading_forecasting;

-- Median
SELECT `Muppandal_temperature_2m` AS median_muppandal_temp
FROM (
    SELECT `Muppandal_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Muppandal_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Muppandal_temperature_2m` AS mode_muppandal_temp
FROM (
    SELECT `Muppandal_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Muppandal_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Muppandal_temperature_2m`) AS stddev_muppandal_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Muppandal_temperature_2m`) AS variance_muppandal_temp FROM power_trading_forecasting;
SELECT MAX(`Muppandal_temperature_2m`) AS max_muppandal_temp,
       MIN(`Muppandal_temperature_2m`) AS min_muppandal_temp FROM power_trading_forecasting;

-- Skewness
SELECT
(
SUM(POWER(`Muppandal_temperature_2m` -
(SELECT AVG(`Muppandal_temperature_2m`) FROM power_trading_forecasting), 3)) /
(COUNT(*) * POWER((SELECT STDDEV(`Muppandal_temperature_2m`) FROM power_trading_forecasting), 3))
) AS skewness_muppandal_temp
FROM power_trading_forecasting;

-- Kurtosis
SELECT
(
(
SUM(POWER(`Muppandal_temperature_2m` -
(SELECT AVG(`Muppandal_temperature_2m`) FROM power_trading_forecasting), 4)) /
(COUNT(*) * POWER((SELECT STDDEV(`Muppandal_temperature_2m`) FROM power_trading_forecasting), 4))
) - 3
) AS kurtosis_muppandal_temp
FROM power_trading_forecasting;


-- =========================================
-- MUPPANDAL HUMIDITY (%)
-- =========================================

SELECT AVG(`Muppandal_relative_humidity_2m`) AS mean_muppandal_humidity FROM power_trading_forecasting;
SELECT STDDEV(`Muppandal_relative_humidity_2m`) AS stddev_muppandal_humidity FROM power_trading_forecasting;
SELECT VARIANCE(`Muppandal_relative_humidity_2m`) AS variance_muppandal_humidity FROM power_trading_forecasting;
SELECT MAX(`Muppandal_relative_humidity_2m`) AS max_muppandal_humidity,
       MIN(`Muppandal_relative_humidity_2m`) AS min_muppandal_humidity FROM power_trading_forecasting;


-- =========================================
-- MUPPANDAL CLOUD COVER (%)
-- =========================================

SELECT AVG(`Muppandal_cloud_cover`) AS mean_muppandal_cloud FROM power_trading_forecasting;
SELECT STDDEV(`Muppandal_cloud_cover`) AS stddev_muppandal_cloud FROM power_trading_forecasting;
SELECT VARIANCE(`Muppandal_cloud_cover`) AS variance_muppandal_cloud FROM power_trading_forecasting;
SELECT MAX(`Muppandal_cloud_cover`) AS max_muppandal_cloudcover,
       MIN(`Muppandal_cloud_cover`) AS min_muppandal_cloudcover FROM power_trading_forecasting;


-- =========================================
-- MUPPANDAL WIND SPEED (km/h)
-- =========================================

SELECT AVG(`Muppandal_wind_speed_10m`) AS mean_muppandal_wind FROM power_trading_forecasting;

SELECT `Muppandal_wind_speed_10m` AS median_muppandal_wind
FROM (
    SELECT `Muppandal_wind_speed_10m`,
           ROW_NUMBER() OVER (ORDER BY `Muppandal_wind_speed_10m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Muppandal_wind_speed_10m`) AS stddev_muppandal_wind FROM power_trading_forecasting;
SELECT VARIANCE(`Muppandal_wind_speed_10m`) AS variance_muppandal_wind FROM power_trading_forecasting;
SELECT MAX(`Muppandal_wind_speed_10m`) AS max_muppandal_windspeed,
       MIN(`Muppandal_wind_speed_10m`) AS min_muppandal_windspeed FROM power_trading_forecasting;


-- =========================================
-- MUPPANDAL SOLAR RADIATION (W/m²)
-- =========================================

SELECT AVG(`Muppandal_shortwave_radiation`) AS mean_muppandal_radiation FROM power_trading_forecasting;

SELECT `Muppandal_shortwave_radiation` AS median_muppandal_radiation
FROM (
    SELECT `Muppandal_shortwave_radiation`,
           ROW_NUMBER() OVER (ORDER BY `Muppandal_shortwave_radiation`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

SELECT STDDEV(`Muppandal_shortwave_radiation`) AS stddev_muppandal_radiation FROM power_trading_forecasting;
SELECT VARIANCE(`Muppandal_shortwave_radiation`) AS variance_muppandal_radiation FROM power_trading_forecasting;
SELECT MAX(`Muppandal_shortwave_radiation`) AS max_muppandal_radiation,
       MIN(`Muppandal_shortwave_radiation`) AS min_muppandal_radiation FROM power_trading_forecasting;


-- =========================================
-- KHAVDA TEMPERATURE (°C)
-- =========================================

-- Mean
SELECT AVG(`Khavda_temperature_2m`) AS mean_khavda_temp FROM power_trading_forecasting;

-- Median
SELECT `Khavda_temperature_2m` AS median_khavda_temp
FROM (
    SELECT `Khavda_temperature_2m`,
           ROW_NUMBER() OVER (ORDER BY `Khavda_temperature_2m`) AS row_num,
           COUNT(*) OVER () AS total_count
    FROM power_trading_forecasting
) t
WHERE row_num IN ((total_count + 1)/2, (total_count + 2)/2);

-- Mode
SELECT `Khavda_temperature_2m` AS mode_khavda_temp
FROM (
    SELECT `Khavda_temperature_2m`, COUNT(*) AS frequency
    FROM power_trading_forecasting
    GROUP BY `Khavda_temperature_2m`
    ORDER BY frequency DESC
    LIMIT 1
) t;

SELECT STDDEV(`Khavda_temperature_2m`) AS stddev_khavda_temp FROM power_trading_forecasting;
SELECT VARIANCE(`Khavda_temperature_2m`) AS variance_khavda_temp FROM power_trading_forecasting;
SELECT MAX(`Khavda_temperature_2m`) AS max_khavda_temp,
       MIN(`Khavda_temperature_2m`) AS min_khavda_temp FROM power_trading_forecasting;
